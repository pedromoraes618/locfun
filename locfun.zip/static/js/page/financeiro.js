$('#parceiro').select2();
