<?php
unset($_SESSION["user_loc_fun"]);
header("Location: ?login");
