<?php
//servidor local
$servidor="localhost";
$usuario="root";
$senha="";
$banco="locfun";
$conecta=mysqli_connect($servidor, $usuario, $senha, $banco);

?>