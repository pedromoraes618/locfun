<div class="p-3 shadow">
    <span class="badge mb-3 text-bg-dark">Consulta log</span>
    <form action="" method="POST">

        <div class="row">
            <div class="col-md  mb-2">
                <div class="input-group">
                    <input type="text" class="form-control" name="pesquisa_conteudo" value="<?php echo $conteudo_pesquisa; ?>" placeholder="Pesquise pelo nome de usuário ou pelo código" aria-label="Recipient's username" aria-describedby="button-addon2">
                    <button class="btn btn-outline-secondary" type="submit" id="pesquisar_filtro_pesquisa">Pesquisar</button>
                </div>
            </div>
        </div>
    </form>
    <div class="table-container">
        <table class="table  table-hover">
            <?php
            if ($qtd_consultar_log > 0) {
            ?>
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Usuário</th>
                        <th>Ação</th>
             
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($linha = mysqli_fetch_assoc($consultar_log)) {
                        $data_hora = formatarTimeStamp($linha['data_hora']);
                        $acao = $linha['acao'];
                        $usuario = ($linha['usuario']);


                    ?>
                        <tr>
                            <td><?php echo $data_hora; ?></td>
                            <td><?php echo $usuario; ?></td>
                            <td><?php echo ($acao); ?></td>
                         
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>

            <?php

            }
            ?>
        </table>
    </div>

</div>